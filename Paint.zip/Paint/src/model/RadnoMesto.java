package model;

public enum RadnoMesto {
	MODELATOR,
	RIGER,
	ANIMATOR,
	ILUSTRATOR
}
